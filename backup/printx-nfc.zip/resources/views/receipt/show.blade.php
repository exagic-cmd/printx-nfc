@extends('layouts.app')

@section('css')
<style>
  .btn{
        border: 1px solid;
    background: gray;
    color: white;
    }
</style>
<link rel="stylesheet" href="{{ asset('css/style.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
@stop

@section('content')
<!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Detail Record</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--end::App Content Header-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
          <div class="vcard-container">
        <div class="vcard-header">
            <img src="{{asset('assets/img/user2-160x160.jpg')}}" alt="Profile Photo" class="profile-image">
            <h1> {{ $receipt->name }}</h1>
            <div class="title"> {{ $receipt->designation }}</div>
        </div>
        
        <div class="vcard-body">
            <div class="contact-info">
                <div class="contact-item">
                    <i class="fas fa-home"></i>
                    <span> {{ $receipt->company }}</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <span> {{ $receipt->phone }}</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <span> {{ $receipt->office_phone }}</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-envelope"></i>
                    <span> {{ $receipt->email }}</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-globe"></i>
                    <span>{{$receipt->website}}</span>
                </div>
                <div class="contact-item">
                <i class="fab fa-facebook-f"></i>
                    <span>{{$receipt->facebook}}</span>
                </div>
                <div class="contact-item">
                <i class="fab fa-instagram"></i>
                    <span>{{$receipt->instagram}}</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>{{$receipt->address}}</span>
                </div>
            </div>
            
    <a href="{{ route('vcard.download', $receipt->id) }}" class="btn btn-block btn-info">
    Download VCARD
</a>
    </div>
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->

@stop
