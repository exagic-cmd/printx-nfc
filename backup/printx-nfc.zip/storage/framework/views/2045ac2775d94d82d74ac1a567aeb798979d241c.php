


<?php $__env->startSection('content'); ?>

<!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->

<!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-lg-3 col-6">
                <!--begin::Small Box Widget 1-->
                <div class="small-box text-bg-primary">
                  <div class="inner">
                    <h3><?php echo e($receiptCount); ?></h3>
                    <p>Total Records</p>
                  </div>
                  <a
                    href="<?php echo e(route('all-receipts')); ?>"
                    class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover"
                  >
                    Show all <i class="bi bi-link-45deg"></i>
                  </a>
                </div>
                <!--end::Small Box Widget 1-->
              </div>
              <!--end::Col-->
              <div class="col-lg-3 col-6">
                <!--begin::Small Box Widget 2-->
                <div class="small-box text-bg-success">
                  <div class="inner">
                    <h3><?php echo e($todayReceiptCount); ?></h3>
                    <p>Today's Records</p>
                  </div>
                  <a
                    href="<?php echo e(route('all-receipts')); ?>"
                    class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover"
                  >
                    Show all <i class="bi bi-link-45deg"></i>
                  </a>
                </div>
                <!--end::Small Box Widget 2-->
              </div>
              <!--end::Col-->
              <div class="col-lg-3 col-6">
                <!--begin::Small Box Widget 3-->
                <div class="small-box text-bg-warning">
                  <div class="inner">
                    <h3>309</h3>
                    <p>Active</p>
                  </div>
                  <a
                    href="#"
                    class="small-box-footer link-dark link-underline-opacity-0 link-underline-opacity-50-hover"
                  >
                    More info <i class="bi bi-link-45deg"></i>
                  </a>
                </div>
                <!--end::Small Box Widget 3-->
              </div>
              <!--end::Col-->
              <div class="col-lg-3 col-6">
                <!--begin::Small Box Widget 4-->
                <div class="small-box text-bg-danger">
                  <div class="inner">
                    <h3>12</h3>
                    <p>Non Active</p>
                  </div>
                  <a
                    href="#"
                    class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover"
                  >
                    More info <i class="bi bi-link-45deg"></i>
                  </a>
                </div>
                <!--end::Small Box Widget 4-->
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->
            <div class="row">
              <!-- /.col -->
              <div class="col-md-12">                
                <!-- /.card -->
                <div class="card mb-4">
                  <div class="card-header">
                    <h3 class="card-title">Today's All Records</h3>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body p-0">
                    <table class="table table-striped">
                      <thead>
                      <?php $counter = 1; ?>
                        <tr>
                          <th style="width: 10px">#</th>
                          <th>Name</th>
                          <th>Designation</th>
                          <th>Company</th>
                          <th>Phone</th>
                          <th>Office Phone</th>
                          <th>Email</th>
                          <th>Website</th>
                          <th>Facebook</th>
                          <th>Instagram</th>
                          <th>Office Address</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $todayReceipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                          <td><?php echo e($counter); ?>.</td>
                          <td><?php echo e($receipt->name); ?></td>
                          <td><?php echo e($receipt->designation); ?></td>
                          <td><?php echo e($receipt->company); ?></td>
                          <td><?php echo e($receipt->phone); ?></td>
                          <td><?php echo e($receipt->office_phone); ?></td>
                          <td><?php echo e($receipt->email); ?></td>
                          <td><?php echo e($receipt->website); ?></td>
                          <td><?php echo e($receipt->facebook); ?></td>
                          <td><?php echo e($receipt->instagram); ?></td>
                          <td><?php echo e($receipt->address); ?></td>
                        </tr>
                        <?php $counter++; ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($todayReceipts->isEmpty()): ?>
                            <p class="text-muted text-center">No receipts found for today.</p>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
        






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\printx-nfc\resources\views/dashboard.blade.php ENDPATH**/ ?>