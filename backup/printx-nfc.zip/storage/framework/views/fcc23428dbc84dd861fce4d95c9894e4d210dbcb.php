 <div class="qrCode">
 <?php if(!empty($data['qrimage'])): ?>
    <img src="<?php echo e($data['qrimage']); ?>" alt="QR Code">
<?php endif; ?>
</div><?php /**PATH E:\xampp\htdocs\printx-nfc\resources\views/receipt/partials/receipt.blade.php ENDPATH**/ ?>