<!DOCTYPE html>
<html>
<head>
    <title>Tahseel Receipt</title>
    <?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
</head>
<body>
<div class="ticket show card-body" id="printableArea">
                      <img class="barcode hidden" id="barcode1" src="<?php echo e(asset('barcode.png')); ?>" alt="barcode">
                      <img class="logo" src="<?php echo e(asset('logo.png')); ?>" alt="Logo">
                      <p class="centered" style="margin-top: 10px;margin-bottom:3px; font-weight: 500">حكومة الشارقة
                          <br>ه‍ينة ا لطرق و المواصلات دالرة ا لما لية المركزية
                          <br>  نظام التعرفة المرورية للشاحنات   &nbsp;&nbsp;&nbsp;  نظا م تحصيل
                      </p>
                      <p style="margin-top: 0;text-align: right;padding-right:52px;height:2px" id="titleTop">
                          <?php echo e($receipt->gate); ?>

                      </p>
                      <p class="centered" style="height: 0px;font-family: auto;">(Payment Receipt)</p>
                      <p class="centered" style="height: 3px; font-family: auto;">Tax Invoice / فاتورة قضريبية
                      </p>
                      <p class="centered" style="height: 3px; font-family: auto;">TRN: <span id="trn"><?php echo e($receipt->trn); ?></span></p>
                      <table>
                          <tbody>
                              <tr>
                                  <td class="description" style="direction:rtl" id="tim"><?php echo e($receipt->time); ?></td>
                                  <td class="description"style="width: 1px;">:الوقت</td>
                                  <td class="description" style="width: 114px;" >&nbsp;&nbsp;&nbsp;:التاريخ<span style="font-size:13px;padding-right: 5px;" id="dte"><?php echo e($receipt->date); ?></span></td>
                              </tr>
                              <tr>
                                  <td class="description" colspan="3" >رقم الايصال:&nbsp;&nbsp;<span id="amt"><?php echo e($receipt->receipt_number); ?></span></td>
                              </tr>
                              <tr>
                                  <td class="description" colspan="3"><span>نوع لخدمة:&nbsp;&nbsp;&nbsp;&nbsp;</span>رسوم عبور شاحنة مع مقطورة</td>
                              </tr>
                              <tr>
                                  <td class="description" colspan="3">&nbsp;&nbsp;اسم المالك :&nbsp;<span id="vName"><?php echo e($receipt->owner_name); ?></span>&nbsp;</td>
                              </tr>
                              <tr>
                                  <td class="description" colspan="3" ><span id="vNo"style="display: inline-block;"><?php echo e($receipt->vehicle_number); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;:رقم المركبة</td>
                              </tr>
                              <tr>
                                  <td class="description"  colspan="2"><span class="pdL33">درهم&nbsp;&nbsp;<span id="tAmt" style="display: inline-block;"> <?php echo e($receipt->total_amount); ?></span></span></td>
                                  <td class="description" colspan="1"><span></span>:اجمالى المبلغ </td>
                              </tr>
                              <tr>
                                  <td class="quantity" colspan="1">&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                  <td class="description" colspan="2">رسوم اخرى</td>
                              </tr>
                              <tr>
                                  <td class="quantity" colspan="1">درهم&nbsp;&nbsp;<span id="temAmt" style="display: inline-block;"><?php echo e($receipt->research_support); ?></span></td>
                                  <td class="description" colspan="4"><p style="font-size:12px; margin:0">:دعم الا بحات العلمية فى امارة الشارقة</p></td>
                              </tr>
                              <tr>
                                  <td class="quantity" colspan="1">درهم&nbsp;&nbsp;<span id="charAmt" style="display: inline-block;"><?php echo e($receipt->collection_fee); ?></span></td>
                                  <td class="description" colspan="4">:رسوم خدمت تحصيل</td>
                              </tr>
                              <tr>
                                  <td class="quantity"colspan="1">درهم&nbsp;&nbsp;<span id="lstAmt" style="display: inline-block;"><?php echo e($receipt->vat); ?></span></td>
                                  <td class="description" colspan="4">:رسوم طرمية النيمة المضا فة</td>
                              </tr>
                          </tbody>
                      </table>
                      <p class="centered" style="height: 3px;font-family: auto;"> Gate<span id="gNo"><?php echo e($receipt->user_name); ?></span>:اسم لستخدم</p>
                      <p class="centered" style="height: 3px; font-size: 12px"> ملاحظه:   ير جى لا حنفاظ يايصال تحصيل ندواعى امية</p>
                      <!-- <div class="qrCode">
						<?php if(!empty($data['qrimage'])): ?>
							<img src="<?php echo e($data['qrimage']); ?>" alt="QR Code">
						<?php endif; ?>
						</div> -->
</body>
</html>
<?php /**PATH E:\xampp\htdocs\Tahseel\receipt_project\resources\views/invoice.blade.php ENDPATH**/ ?>