<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Receipt;
use Illuminate\Support\Facades\Response;

class VCardController extends Controller
{
    public function download($id)
    {
        $receipt = Receipt::findOrFail($id);

        $vcard = "BEGIN:VCARD\n";
        $vcard .= "VERSION:3.0\n";
        $vcard .= "FN:{$receipt->name}\n";
        $vcard .= "TITLE:{$receipt->designation}\n";
        $vcard .= "ORG:{$receipt->company}\n";
        $vcard .= "TEL;TYPE=CELL:{$receipt->phone}\n";
        $vcard .= "TEL;TYPE=WORK:{$receipt->office_phone}\n";
        $vcard .= "EMAIL:{$receipt->email}\n";
        $vcard .= "URL:{$receipt->website}\n";
        $vcard .= "ADR:;;{$receipt->address}\n";

        // Separate social links
        if (!empty($receipt->facebook)) {
            $vcard .= "X-SOCIALPROFILE;type=facebook:{$receipt->facebook}\n";
        }
        if (!empty($receipt->instagram)) {
            $vcard .= "X-SOCIALPROFILE;type=instagram:{$receipt->instagram}\n";
        }

        $vcard .= "END:VCARD\n";

        $fileName = 'vcard_' . strtolower(str_replace(' ', '_', $receipt->name)) . '.vcf';

        return Response::make($vcard, 200, [
            'Content-Type' => 'text/vcard',
            'Content-Disposition' => "attachment; filename={$fileName}",
        ]);
    }
}
